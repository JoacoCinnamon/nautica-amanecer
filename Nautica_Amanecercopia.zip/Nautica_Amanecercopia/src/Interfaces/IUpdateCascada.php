<?php
interface IUpdateCascada
{
  public function updateEnCascada();
}
